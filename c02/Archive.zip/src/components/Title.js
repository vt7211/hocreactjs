import React from 'react';

function Title() {
    return (
        <div className="page-header">
            <h1>Project 01 - ToDo ss <small>ReactJS</small></h1>
        </div>
    );
}

export default Title;
