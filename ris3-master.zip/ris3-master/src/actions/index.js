import * as counter from './counter';
import * as common from './common';

export default {
  counter,
  common,
};
