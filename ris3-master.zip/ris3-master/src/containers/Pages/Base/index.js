import Wrapper from './styles';

export default function Base() {
  return (
    <Wrapper>
      <h1>BASE PAGE</h1>
    </Wrapper>

  );
}
