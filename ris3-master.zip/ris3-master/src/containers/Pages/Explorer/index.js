export default function Explorer() {
  return (
    <h1>Explorer</h1>
  );
}
